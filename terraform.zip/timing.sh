#!/bin/bash
sudo -Hu centos yum info selinux-policy
sudo -Hu centos yum info selinux-policy-targeted
sudo -Hu centos yum info sudo
{ time sudo true ; } 2> timing.txt